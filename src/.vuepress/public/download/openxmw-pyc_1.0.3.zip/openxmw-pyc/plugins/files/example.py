def example(params):
    print('example plugin')
    return 'example plugin'